package com.example.orientationlistviewproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<Sax> saxArrayList;
    TextView name;
    ImageView image;
    Button remove;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Sax item = (Sax) adapterView.getItemAtPosition(i);
                name = view.findViewById(R.id.textView2);
                if (name.getText().equals(item.getModel())) {
                    name.setText(item.getMoreInfo());
                }
                else {
                    name.setText(item.getModel());
                }

            }
        });
        saxArrayList = new ArrayList<>();
        saxArrayList.add(new Sax("Selmer", R.drawable.selmer, "The Selmer Mark VI is a saxophone produced from 1954 to 1981. Production shifted to the Mark VII for the tenor and alto in the mid-1970s (see discussion of serial numbers below), and to the Super Action 80 for the soprano and baritone saxophones in 1981. The sopranino saw limited production until about 1985.\n" +
                "\n" +
                "Selmer debuted the Mark VI in 1954 with sopranino, soprano, alto, tenor, baritone and bass saxophones, until the introduction of the Mark VII model in 1975. Since the Mark VI design continued for sopraninos, sopranos, baritones, or bass saxes, they did not have a Mark VII model. There are reports of a limited number of baritone saxophones labeled as Mark VIIs, but these horns were of the same design as the Mark VI.\n" +
                "\n" +
                "All Mark VI saxophones were manufactured in France. After manufacture, instruments designated for the British/Canadian or American markets were shipped unassembled and unengraved to their respective markets for completion. The style of engraving on the bell of the instrument is an indicator of the place of assembly."));
        saxArrayList.add(new Sax("Yahama", R.drawable.yahama, "One of the best-made altos available, the YAS-62III features fully ribbed construction, yet its weight is comfortable and well balanced. It is hand-adjusted, and the two-piece bell, body and neck and are all hand-hammered. Its new engraving design is done by hand, instilling a uniqueness into each instrument. Multiple key posts are integrated into a single plate. This lends the horn moderate resistance while delivering a solid core with deep tone color. Hard steel needle springs offer a fast, sensitive key response. It has a Front F key along with a high F# key and an adjustable thumb rest."));
        saxArrayList.add(new Sax("Yanigisawa", R.drawable.yanigisawa, "Yanagisawa has become known for their reputation for high quality and hand craftsmanship. The family legacy dates back to 1893 with Tokutaro Yanagisawa repairing woodwind instruments in Japan for military band members. In 1921, Yanagisawa established their first factory making trumpets and cornets. During this time, Tokutaro would mentor young instrument makers including Kouichi Muramatsu, who would eventually build his own flute company.\n" +
                "\n" +
                "In 1951, Takutaro's son, Takanobu Yanagisawa followed in his father's footsteps to build his first prototype saxophone. During the 60's and 70's, Yanagisawa developed and built new models of saxophones including the model B-6 bari saxophone and the S-6 soprano saxophone, the first ever of their type to be built in Japan."));
        saxArrayList.add(new Sax("Cannonball", R.drawable.cannonball,"Cannonball saxophones have eye catching exterior design. Before purchasing the brand you may be wondering if the instruments are worth the price. \n" +
                "\n" +
                "The strength of Cannonball Saxophone is unique sound and customized aesthetics. Cannonball saxophones are worth the price for intermediate and semi-professional players. Cannonball’s distinct bell and neck design give the horn a bright, edgy sound suitable for jazz rather than classical blending."));
        CustomAdapter adapter = new CustomAdapter(this, R.layout.adapter_layout, saxArrayList);
        listView.setAdapter(adapter);
    }
    public class CustomAdapter extends ArrayAdapter<Sax> {
        List<Sax> list;
        Context context;
        int xmlResource;

        public CustomAdapter(@NonNull Context context, int resource, @NonNull List<Sax> objects) {
            super(context, resource, objects);
            xmlResource = resource;
            list = objects;
            this.context = context;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            View adapterLayout = layoutInflater.inflate(xmlResource, null);
            remove = adapterLayout.findViewById(R.id.button2);
            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   //delete the View
                }
            });
            name = adapterLayout.findViewById(R.id.textView2);
            image = adapterLayout.findViewById(R.id.imageView);
            name.setText(list.get(position).getModel());
            image.setImageResource(list.get(position).getImage());
            return adapterLayout;

        }
    }

//    @Override
//    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
//        super.onSaveInstanceState(outState, outPersistentState);
//        outState.putParcelableArrayList("SAX_LIST", saxArrayList);
//    }
//
//    @Override
//    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
//        super.onRestoreInstanceState(savedInstanceState);
//        saxArrayList = savedInstanceState.getParcelableArrayList("SAX_LIST");
//        update(name, image);
//
//    }
    public void update(TextView model, ImageView image) {
        int i = 0;
        while (i < saxArrayList.size())
        model.setText(saxArrayList.get(i).getModel());
        image.setImageResource(saxArrayList.get(i).getImage());
        i++;
    }
}