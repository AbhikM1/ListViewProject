package com.example.orientationlistviewproject;

import android.os.Parcel;
import android.os.Parcelable;

public class Sax implements Parcelable {
    String model;
    int image;
    String moreInfo;
    public Sax(String model, int image, String moreInfo) {
        this.model = model;
        this.image = image;
        this.moreInfo = moreInfo;

    }
    public String getModel() {
        return model;
    }
    public int getImage() {
        return image;
    }
    public String getMoreInfo() {return moreInfo;}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

    }
}
